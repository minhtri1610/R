install.packages('factoextra')
install.packages("BSDA")

library(BSDA)
library(ggplot2)
library(factoextra)
library(dplyr)

# Câu 1: Load data Mall_Customers.csv
data <- read.csv("D:/R/TRAN_MINH_TRI/Mall_Customers.csv", header = T)
data

# Câu 2: Trực quan bằng biểu đồ phân phối về độ tuổi của khách hàng
hist(data$Age,
     main = "Trực quan độ tuổi", 
     xlab="Tuổi", 
     ylab = "Số lượng",
     col = "yellow")


# Câu 3: Tạo bảng cross-table cho biết số lượng khách hàng nam nữ
attach(data)
gender <- table(Gender)

# Câu 4: Hãy trực quan bằng biểu đồ biểu đồ cột về số lượng khách hàng nam và nữ
bieudobar <- barplot(table(Gender),
                     main = "BIểu đồ số lượng  khách hàng")

# Câu 5: Sử dụng Anova để phân tích có sự quan hệ gì giữa giới tính và thu nhập không
model <- aov(AnnualIncome~Gender,data=data)
summary(model)
# p-value >0.05
# => Chấp nhận giả thiết H0 <=> Không có mối quan hệ giữa giới tính và thu nhập

# Câu 6: Sử dụng Anova để phân tích có sự quan hệ gì giữa giới tính và chi tiêu không
model <- aov(SpendingScore~Gender,data=data)
summary(model)
# p-value >0.05  
# => Chấp nhận giả thiết H0 <=> Không có mối quan hệ giữa giới tính và chi tiêu

# Câu 7: Vẽ biểu đồ Boxplot thể hiện mức thu nhập trên từng nhóm giới tính
boxplot_thunhap_gioitinh <- boxplot(data$AnnualIncome~data$Gender,
                         xlab="Biến số",
                         ylab="Thu nhập",
                         col="red")

# Câu 8: Vẽ biểu đồ Boxplot thể hiện mức chi tiêu trên từng nhóm giới tính
boxplot_chitieu_gioitinh <- boxplot(data$SpendingScore~data$Gender,
                                    xlab="Biến số",
                                    ylab="Chi tiêu",
                                    col="red")


# Câu 9: Vẽ biểu đồ phân tán thể hiện mối quan hệ giữa thu nhập và chi tiêu
plot(data$AnnualIncome, data$SpendingScore,
     ylab = "Chi tiêu", xlab = "thu nhập", main="Biểu đồ phân tán")


# Câu 10: Vẽ biểu đồ phân tán thể hiện mối quan hệ giữa tuổi và chi tiêu
plot(data$Age, data$SpendingScore,ylab = "Chi tiêu", xlab = "Tuổi", main="Biểu đồ phân tán")

# Câu 11: Hãy xây dựng mô hình hồi quy tuyến tính để dự báo chi tiêu theo thu nhập
plot(data$SpendingScore~data$AnnualIncome)
kq <- lm(data$SpendingScore~data$AnnualIncome)
kq
abline(kq)

# Câu 12: Hãy tóm tắt mô hình hồi quy tuyến tính
summary(kq)
# p_value cho ta thấy 0.8893 > hơn 0.05 nên ta chấp nhận thông số H0, 
# ở đây đưa ra được ý nghĩa rằng biến độc lập và biến phụ thuộc không phụ thuộc lẫn nhau
# Dự báo khoản tin cậy 95%

# Câu 13: Hãy vẽ biểu đồ phần dư của mô hình hồi quy tuyến tính
res = resid(kq)
plot(res, main="Biểu đồ phần dư", abline(0,0))

# Câu 14: Hãy dự báo chi tiêu ở lứa tuổi khách hàng là 27 và thu nhập là 60K / năm


# Câu 15: Hãy phân nhóm dữ liệu dựa trên thu nhập và chi tiêu thành 5 nhóm khách hàng





