

# Để sử dụng dữ liệu có sẵn trong R phục vụ nghiên cứu học tập
# Ta chỉ cần gọi đúng tên của tập dữ liệu

print(airquality)
